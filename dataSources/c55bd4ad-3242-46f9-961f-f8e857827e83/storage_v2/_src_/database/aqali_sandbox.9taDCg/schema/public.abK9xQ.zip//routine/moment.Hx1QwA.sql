create function moment()
  returns timestamp without time zone
language plpgsql
as $$
begin return current_timestamp; end
$$;

