create view clientrecord as
  SELECT c1.id, c1.name, c1.surname, c1.patronymic, date_part('year' :: text, age(
      (c1.birth_date) :: timestamp with time zone)) AS age, max(c2.money) AS max, min(c2.money) AS min, sum(
      c2.money) AS total, c3.name AS charm
  FROM client c1,
       clientaccount c2,
       charm c3
  WHERE ((c1.id = c2.client) AND (c1.charm = c3.id))
  GROUP BY c1.id, c3.name;

